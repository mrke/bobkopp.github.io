function [ExpectedWelfare,scenario] = DICEEconomicModel(p,SavingsRate,miu,damagemodfactor,incrementalemissions,incrementalconsumption,incrementalcapital,incrementalforcing)

%[ExpectedWelfare,scenario] = DICEEconomicModel(p,SavingsRate,miu,[damagemodfactor],[incrementalemissions],[incrementalconsumption],[incrementalcapital],[incrementalforcing])
%
%
%
% Last updated by Bob Kopp rkopp-at-alumni.caltech.edu, 12 February 2012

	Nscenarios = length(p.T2xCO2);

	t=p.t;
	p.lam = p.lam(:);
	Population = repmat(p.L,Nscenarios,1);
	
	SavingsRate=SavingsRate(:)';
	if size(miu,1)==1
		miu=repmat(miu(:)',Nscenarios,1);
	end

	defval('damagemodfactor',1);
	defval('incrementalemissions',zeros(size(t)));
	defval('incrementalconsumption',zeros(size(t)));
	defval('incrementalcapital',zeros(size(t)));
	defval('incrementalforcing',zeros(size(t)));

	if p.elasmu == 1
		calcutility = @(ConsumptionPC) real ( log(max(p.mincons/1000,ConsumptionPC)) );
		p.elasmu = 1.0001;
	else
		calcutility = @(ConsumptionPC) real ( ((max(p.mincons/1000,ConsumptionPC)).^(1-p.elasmu))./(1-p.elasmu) );
	end
	
	if p.ecoelasticity == 1
		p.ecoelasticity = 0.9999;
	end


	calcnextmassdist = @(mass0,emissions) mass0 * p.b + [emissions zeros(Nscenarios,2)]; 
	calcnexttemperature = @(Atm,Ocean,Forcing) [Atm+p.c1*(Forcing-p.lam.*Atm-p.c3*(Atm-Ocean)) Ocean+p.c4*(Atm-Ocean)];
	calcoutput_gross = @(TFP,Kapital,Labor) TFP .* Labor.^(1-p.gama) .* Kapital.^(p.gama);
	calcdamages = p.calcdamages;
	calcabatecost = @(PartFraction,CostFactor,Mitigation) (PartFraction^(1-p.expcost2))*(CostFactor*Mitigation.^p.expcost2);
	calcco2forcing = @(AtmCO2) p.FCO22x*log2((AtmCO2+1e-9)/p.matPI);

	
	Tatm(:,1) = ones(Nscenarios,1)*p.Tatm0;
	preTatm = Tatm(:,1) - (p.t(2)-p.t(1))*p.Trate0;
	Tocean(:,1) = ones(Nscenarios,1)*p.Tocean0;
	if Nscenarios>1
		MassDist(1,:,:) = repmat([p.mat2005 p.mu2005 p.ml2005],[1 1 Nscenarios]);
	else
		MassDist(1,:) = [p.mat2005 p.mu2005 p.ml2005];
	end
	ForcingNonCO2(:,1) = repmat(p.forcoth(1),Nscenarios,1)+incrementalforcing(:,1);
	Forcing(:,1) = squeeze(calcco2forcing(MassDist(1,1,:)))+ForcingNonCO2(:,1);
	CumulativeEmissions(:,1) = zeros(Nscenarios,1);
	dTatm(:,1) = ones(Nscenarios,1)*p.Trate0;

	Capital(:,1) = ones(Nscenarios,1)*p.k0;
	CapitalClimateDamages(:,1) = zeros(size(Capital(:,1)));
	Capital(:,1) = Capital(:,1) + incrementalcapital(1);
	for i=1:length(t)
	
		if i>1
			if Nscenarios > 1
				MassDist(i,:,:) = reshape(calcnextmassdist(squeeze(MassDist(i-1,:,:))',Emissions(:,i-1))',1,3,Nscenarios);
				MassDist(i,:,:) = MassDist(i,:,:).*(MassDist(i,:,:)>0);
			else
				MassDist(i,:) = calcnextmassdist(MassDist(i-1,:),Emissions(i-1));
				MassDist(i,:) = MassDist(i,:).*(MassDist(i,:)>0);
			end
			forcothmiu(:,i) = miu(:,i-1)*p.forcothmiufactor;
			forcothmiu(:,i) = (forcothmiu(:,i)<=p.forcothlimmiu).*forcothmiu(:,i) + p.forcothlimmiu.*(forcothmiu(:,i)>p.forcothlimmiu);
			ForcingNonCO2(:,i)=real((p.forcoth(i)*(1-forcothmiu(:,i)))+incrementalforcing(:,i));
			Forcing(:,i) = real(calcco2forcing(squeeze(MassDist(i,1,:)))+ForcingNonCO2(:,i));
			temps = real(calcnexttemperature(Tatm(:,i-1),Tocean(:,i-1),.5*(Forcing(:,i)+Forcing(:,i-1))));
			CumulativeEmissions(:,i) = CumulativeEmissions(:,i-1) + Emissions(:,i-1);

			Tatm(:,i) = temps(:,1); Tocean(:,i) = temps(:,2);
			dTatm(:,i) = (Tatm(:,i)-Tatm(:,i-1))/(t(i)-t(i-1));
			
			Capital(:,i) = Capital(:,i-1)*(1-p.dk).^(t(i)-t(i-1)) + Investment(:,i-1)*(t(i)-t(i-1));
			CapitalClimateDamages(:,i) = 1 - (1 - damagemodfactor*calcdamages(abs(Tatm(:,i)),t(i),dTatm(:,i),Output_Gross(:,i-1),[preTatm Tatm],p.L(i))).^(p.dam_fcapital./p.gama);
			Capital(:,i) = Capital(:,i) .* (1 - CapitalClimateDamages(:,i));
			Capital(:,i) = Capital(:,i) + incrementalcapital(i);
		end			
			
			
	
		Output_Gross(:,i) = calcoutput_gross(p.al(:,i),Capital(:,i),Population(:,i));
		% hard upper limit to carbon
		miu(:,i) = miu(:,i) .* (CumulativeEmissions(:,i)<p.fosslim) + (CumulativeEmissions(:,i)>=p.fosslim);
		
		FossilEmissions(:,i) = (t(2)-t(1))*p.sigma(i)*(1-miu(:,i)).*Output_Gross(:,i);
		Emissions(:,i) = FossilEmissions(:,i) + p.etree(i)*(1-miu(:,i)) + incrementalemissions(i);  

		ClimateDamages(:,i) = 1 - (1 - damagemodfactor*calcdamages(abs(Tatm(:,i)),t(i),dTatm(:,i),Output_Gross(:,i),[preTatm Tatm],p.L(i))).^(1-p.dam_fcapital-p.dam_futility);
		AbatementCost(:,i) = calcabatecost(p.partfract(i),p.cost1(i),miu(:,i));
		%AbatementCost_Marginal(:,i) = AbatementCost(:,i) .* p.expcost2./miu(:,i) .* Output_Gross(:,i) * 1e12 ./ (p.sigma(i) * Output_Gross(:,i) * 1e9);

		Output(:,i) = Output_Gross(:,i) .* (1-ClimateDamages(:,i)-AbatementCost(:,i));

		minOutput = p.minoutpc*1e-6*Population(:,i);
		if p.popfeedback
			Population(:,i) = Population(:,i).*(Output(:,i)>minOutput) + (Output(:,i)/(p.minoutpc*1e-6)).*(Output(:,i)<=minOutput);
		else
			Output(:,i) = Output(:,i).*(Output(:,i)>minOutput) + minOutput.*(Output(:,i)<=minOutput); % ensure output doesn't fall below $730/person
		end
		Investment(:,i) = Output(:,i) * SavingsRate(i);
		
		EcoClimateDamages(:,i) = 1 - (1 - damagemodfactor*calcdamages(abs(Tatm(:,i)),t(i),dTatm(:,i),Output_Gross(:,i),[preTatm Tatm],p.L(i))).^(1-p.dam_futility);
		EffectiveConsumptionDamages(:,i) = 1 - (1 - damagemodfactor*calcdamages(abs(Tatm(:,i)),t(i),dTatm(:,i),Output_Gross(:,i),[preTatm Tatm],p.L(i))).^(p.dam_futility);
	end
	
	Consumption = Output.*repmat((1-SavingsRate),Nscenarios,1) + repmat(incrementalconsumption/(t(2)-t(1)),Nscenarios,1); 
	ConsumptionPerCapita = 1000*Consumption./Population;

	EcoConsumptionPerCapita = repmat(ConsumptionPerCapita(:,1),1,size(EcoClimateDamages,2)).*(1-EcoClimateDamages);

	ppmCO2=squeeze(MassDist(:,1,:))' /2.13;

	if p.ecoshare==0
		EffectiveConsumptionPerCapita = ConsumptionPerCapita .* (1 - EffectiveConsumptionDamages);
		EquivalentMaterialConsumptionPerCapita = EffectiveConsumptionPerCapita;
	else
		if length(p.ecoshare)>1
			ecosh = repmat(p.ecoshare,1,length(t));
		else
			ecosh = p.ecoshare;
		end
		
		if length(p.ecoelasticity)>1
			ecoel = repmat(p.ecoelasticity,1,length(t));
		else
			ecoel = p.ecoelasticity;
		end
		EffectiveConsumptionPerCapita = ((1-ecosh).*ConsumptionPerCapita.^(1-1./ecoel) + ecosh .* EcoConsumptionPerCapita.^(1-1./ecoel)).^(ecoel./(ecoel-1));
		EffectiveConsumptionPerCapita = EffectiveConsumptionPerCapita .* (1 - EffectiveConsumptionDamages);
		EquivalentMaterialConsumptionPerCapita = ( ( ( (1-ecosh).*ConsumptionPerCapita.^(1-1./ecoel) + ecosh .* EcoConsumptionPerCapita.^(1-1./ecoel) - ecosh .* repmat(EcoConsumptionPerCapita(:,1).^(1-1./ecoel(:,1)),1,length(p.t)) ) ./ (1-ecosh)) .^ (ecoel./(ecoel-1)) ) .* (1 - EffectiveConsumptionDamages);
	end

	UtilityPC = calcutility(EffectiveConsumptionPerCapita);
	

	if p.ecoshare == 0
		EquivalentMaterialUtilityPC = UtilityPC;
	else
		EquivalentMaterialUtilityPC = calcutility(EquivalentMaterialConsumptionPerCapita);
	end

	% scale utility
%	utilscalptsx = 5 * [1 2];
%	utilscalptsy = calcutility(utilscalptsx);
%	UtilityPC = utilscalptsx(1) + (UtilityPC - utilscalptsy(1)) * diff(utilscalptsx)/diff(utilscalptsy);
%	EquivalentMaterialUtilityPC = utilscalptsx(1) + (EquivalentMaterialUtilityPC - utilscalptsy(1)) * diff(utilscalptsx)/diff(utilscalptsy);


	UtilityDiscountedTotal = real(UtilityPC .* Population .* repmat(p.rr,Nscenarios,1));
	Welfare = sum(UtilityDiscountedTotal,2);
	ExpectedWelfare = mean(Welfare);

	if p.ecoshare == 0
		EquivalentMaterialWelfare = Welfare;
		EquivalentMaterialExpectedWelfare = ExpectedWelfare;
	else
		EquivalentMaterialWelfare = sum(real(EquivalentMaterialUtilityPC .* Population .* repmat(p.rr,Nscenarios,1)),2);
		EquivalentMaterialExpectedWelfare = mean(EquivalentMaterialWelfare);
	end

	% calculate discount rates
	Growth = ConsumptionPerCapita./repmat(ConsumptionPerCapita(:,1),1,size(ConsumptionPerCapita,2));
	EffectiveGrowth = EffectiveConsumptionPerCapita./repmat(EffectiveConsumptionPerCapita(:,1),1,size(ConsumptionPerCapita,2));
	DiscountFactor = repmat(p.rr,Nscenarios,1).*(Growth.^-p.elasmu);
	EffectiveDiscountFactor = repmat(p.rr,Nscenarios,1).*(EffectiveGrowth.^-p.elasmu);

	scenario.Population = Population;	
	scenario.ExpectedWelfare = ExpectedWelfare;
	scenario.Welfare = Welfare;
	scenario.abatement = miu;
	scenario.abatementnonco2 = forcothmiu;
	scenario.Consumption = Consumption;
	scenario.ConsumptionPerCapita = ConsumptionPerCapita;
	scenario.EcoConsumptionPerCapita = EcoConsumptionPerCapita;
	scenario.EffectiveConsumptionPerCapita = EffectiveConsumptionPerCapita;
	scenario.UtilityPerCapita = UtilityPC;
	scenario.Output_Gross = Output_Gross;
	scenario.Output = Output;
	scenario.Investment = Investment;
	scenario.Capital = Capital;
	scenario.ClimateDamages = ClimateDamages;
	scenario.EcoClimateDamages = EcoClimateDamages;
	scenario.CapitalClimateDamages = CapitalClimateDamages;
	scenario.AbatementCost = AbatementCost;
	scenario.FossilEmissions = FossilEmissions;
	scenario.Emissions = Emissions;
	scenario.Tatm = Tatm;
	scenario.Tocean = Tocean;
	scenario.ppmCO2 = ppmCO2;
	scenario.Forcing = Forcing;
	scenario.ForcingNonCO2 = ForcingNonCO2;
%	scenario.UtilityScalePoints = [utilscalptsy(:) utilscalptsx(:)];
	scenario.EquivalentMaterialConsumptionPerCapita = EquivalentMaterialConsumptionPerCapita;
	scenario.EquivalentMaterialUtilityPerCapita = EquivalentMaterialUtilityPC;
	scenario.EquivalentMaterialWelfare = EquivalentMaterialWelfare;
	scenario.EquivalentMaterialExpectedWelfare = EquivalentMaterialExpectedWelfare;
	scenario.DiscountFactor = DiscountFactor;
	scenario.EffectiveDiscountFactor = EffectiveDiscountFactor;
end