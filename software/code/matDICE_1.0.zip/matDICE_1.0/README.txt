matDICE 1.0
Copyright (C) 2012 by Robert E. Kopp; distributed under GNU GPL v3
Code version: 2012-03-24

This MATLAB-based variant of Nordhaus's Dynamic Integrated Climate Economic (DICE) model was used for

  Robert E. Kopp, Alexander Golub, Nathaniel O. Keohane, and Chikara Onda (2012).
  The Influence of the Specification of Climate Change Damages on the Social Cost
  of Carbon. Economics: The Open-Access, Open-Assessment E-Journal, Vol. 6, 2012-13.
  http://dx.doi.org/10.5018/economics-ejournal.ja.2012-13

It is known to run in MATLAB R2011b, and likely in numerous earlier versions. It requires the Optimization Toolbox to do optimizations.

The script matDICE_script_Koppetal2012.m was used to perform the calculations and generate figures and tables for the manuscript; it provides an example of the usage of the code.

matDICE is the main interface function, in both simulation and optimization modes; please see "help matDICE" for more information.

Please contact Bob Kopp at robert-dot-kopp-at-rutgers-dot-edu for more information

Included files:

* COPYRIGHT - copyright notice (GNU GPL v. 3)

* defval.m - by Frederik Simons (Princeton University); helper function used for setting default values for function inputs

* DICEEconomicModel.m - core economic and climate model

* DICEFitRefScenario.m - used for transforming arbitrary GDP, Population, and Emissions pathways into a form usable as matDICE parameter inputs

* DICEParameters.m - creates parameter structures for use by matDICE

* icdfRoeBaker.m - inverse CDF for a Roe & Baker (2007) probability distribution for climate sensitivity

* icdftri.m - inverse CDF for a triangular distribution

* matDICE_script_Koppetal2012.m - script used for performing the calculations and generating figures/tables for Kopp et al. (2012)

* matDICE.m - main interface function; 

* README.txt - this file

* SCC.m  - calculates social cost of carbon